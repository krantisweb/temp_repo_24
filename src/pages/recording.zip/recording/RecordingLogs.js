import React, { useState,useEffect } from 'react';
import '@mdi/font/css/materialdesignicons.css';
import FolderDetails from './FolderDetails'; // Import the new component

const VideoOrganizer = () => {
  const [videoFolders, setVideoFolders] = useState([
    {
      name: 'Folder 1',
      imageUrl: 'Folder1.png',
      videos: ['video1.mp4', 'video2.avi', 'video3.mp4' ,'video8.mp4' , 'video3.mp4' ,'video8.mp4', 'video3.mp4' ,'video8.mp4'],
    },
    {
      name: 'Folder 2',
      imageUrl: 'Folder1.png',
      videos: ['video4.mkv', 'video5.mp4', 'video6.avi', 'video7.mp4', 'video3.mp4' ,'video8.mp4', 'video3.mp4' ,'video8.mp4'],
    },
  ]);

  const [selectedFolder, setSelectedFolder] = useState(null);
  const [localData, setLocalData] = useState(null);

  const handleFolderClick = (folderIndex) => {
    setSelectedFolder(folderIndex);
  };

  const organizeVideos = () => {
    // ... (organizeVideos logic)
  };

  const getCurrentDateTime = () => {
    // ... (getCurrentDateTime logic)
  };

  const handleDownload = (videoName) => {
    // Mock download logic (you can replace this with actual download logic)
    console.log(`Downloading video: ${videoName}`);
  };

  const handleDelete = (videoIndex) => {
    const updatedFolders = [...videoFolders];
    const deletedVideo = updatedFolders[selectedFolder].videos.splice(videoIndex, 1)[0];
    setVideoFolders(updatedFolders);
    console.log(`Deleted video: ${deletedVideo}`);
  };
  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await selectedFolder();
        setLocalData(data);
      } catch (error) {
        // Handle error if needed
        console.error('Error fetching data:', error);
      }
    };
  
    fetchData(); // Immediately invoke the async function
  }, []);
  

  // If a folder is selected, display FolderDetails; otherwise, display the main page
  return (
    <div className="justify-center   grid grid-cols-1 md:grid-cols-1 gap-4 p-4">
      <div className="container mx-auto ">
        {selectedFolder !== null ? (
          <FolderDetails
            folder={videoFolders[selectedFolder]}
            onBackClick={() => setSelectedFolder(null)} // Handle back button click
            onDownload={handleDownload}
            onDelete={handleDelete}
          />
        ) : (
          <div>
            {/* ... (existing code) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 ">
              {videoFolders.map((folder, index) => (
                <div
                  key={index}
                  className={`p-4 w-2/4 mx-auto bg-gray-100 rounded cursor-pointer  shadow-2xl${
                    selectedFolder === index ? 'border-2 border-blue-500' : ''
                  }`}
                  onClick={() => handleFolderClick(index)}
                >
                  <img src={folder.imageUrl} alt={`Folder ${index + 1}`} className="max-h-24 mb-2 mx-auto" />
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default VideoOrganizer;






