import React from 'react';

const FolderDetails = ({ folder, onBackClick, onDownload, onDelete }) => {
  // Check if folder and folder.videos are defined before attempting to map
  if (!folder || !folder.videos) {
    return (
      <div>
        <h2>Error: Folder or videos not found</h2>
        <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded" onClick={onBackClick}>
          Back
        </button>
      </div>
    );
  }

  return (
    <div>
      <h2 className="text-xl font-light mb-2">{`Videos in ${folder.name}`}</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 ">
        {folder.videos.map((video, index) => (
          <div key={index} className="p-8 bg-gray-200 rounded shadow-2xl ">
            {video}
            <div className="mt-2 flex justify-between">
              <button className="text-blue-500" onClick={() => onDownload(video)}>
                <i className="mdi mdi-download"></i>
              </button>
              <button className="text-red-500" onClick={() => onDelete(index)}>
                <i className="mdi mdi-delete"></i>
              </button>
            </div>
          </div>
        ))}
      </div>
      <button
        onClick={onBackClick}
        className="Save-button bg-sky-500 w-20 h-15 mt-14 font-bold flex justify-center items-center text-white w-3/2 p-2 relative rounded-md"
      >
        Back
      </button>
    </div>
  );
};

export default FolderDetails;
